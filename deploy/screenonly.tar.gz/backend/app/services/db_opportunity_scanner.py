from __future__ import annotations
import os
from typing import Any
from sqlalchemy import text
from app.services.signal_fusion import fuse


def configured() -> bool:
    return bool(os.getenv('DATABASE_URL'))




def _classify_scanner_risk(d: dict[str, Any]) -> str:
    """Classify risk from evidence, never from the opportunity score itself."""
    fundamental = float(d.get('fundamental_score') or 50)
    confidence = float(d.get('confidence') or 35)
    move = abs(float(d.get('live_change_pct') or 0))
    volume = float(d.get('live_volume') or 1)
    if fundamental < 45 or (move >= 8 and volume >= 2.0) or confidence < 35:
        return 'High'
    if fundamental < 65 or move >= 5 or confidence < 55:
        return 'Medium'
    return 'Low'

def scan(limit: int = 50, min_score: float = 0, band: str | None = None,
         horizon: str | None = None, symbol: str | None = None) -> list[dict[str, Any]]:
    if not configured():
        return []
    from app.db import SessionLocal
    sql = text('''
      WITH latest_scores AS (
        SELECT DISTINCT ON (os.stock_id) os.*, s.symbol, COALESCE(s.company_name, s.symbol) AS name
        FROM opportunity_scores os
        JOIN stocks s ON s.id = os.stock_id
        ORDER BY os.stock_id, os.created_at DESC
      ),
      latest_live AS (
        SELECT DISTINCT ON (los.symbol) los.symbol, los.score AS live_score, los.created_at AS live_created_at, los.price AS live_price,
               los.change_pct AS live_change_pct, los.volume_multiple AS live_volume, los.band AS live_band
        FROM live_opportunity_signals los
        ORDER BY los.symbol, los.created_at DESC
      )
      SELECT ls.symbol, ls.name, ls.score, ls.horizon, ls.confidence,
             ls.earnings_score, ls.catalyst_score, ls.surprise_score, ls.momentum_score,
             ls.volume_score, ls.technical_score, ls.fundamental_score,
             COALESCE(ll.live_score, ls.score) AS effective_score,
             ll.live_price, ll.live_change_pct, ll.live_volume,
             COALESCE(ll.live_band, CASE WHEN ls.score >= 85 THEN 'Strong Opportunity'
                 WHEN ls.score >= 70 THEN 'Potential Opportunity'
                 WHEN ls.score >= 55 THEN 'Watch' ELSE 'Ignore' END) AS effective_band
      FROM latest_scores ls
      LEFT JOIN latest_live ll ON ll.symbol = ls.symbol
      WHERE COALESCE(ll.live_score, ls.score) >= :min_score
        AND (:band IS NULL OR COALESCE(ll.live_band, CASE WHEN ls.score >= 85 THEN 'Strong Opportunity'
          WHEN ls.score >= 70 THEN 'Potential Opportunity' WHEN ls.score >= 55 THEN 'Watch' ELSE 'Ignore' END) = :band)
        AND (:horizon IS NULL OR ls.horizon = :horizon)
        AND (:symbol IS NULL OR UPPER(ls.symbol) = UPPER(:symbol))
      ORDER BY effective_score DESC, ls.created_at DESC
      LIMIT :limit
    ''')
    with SessionLocal() as db:
        rows = db.execute(sql, {'min_score': min_score, 'band': band, 'horizon': horizon,
                                'symbol': symbol, 'limit': max(1, min(limit, 200))}).mappings().all()
    out=[]
    for r in rows:
        d=dict(r)
        fusion = fuse(float(d['score'] or 0), d.get('live_score'), d.get('live_created_at'))
        score=float(fusion['score'])
        d.update({
            'score': round(score,2), 'band': d['effective_band'] if fusion['source'] == 'durable' else ('Strong Opportunity' if score >= 85 else 'Potential Opportunity' if score >= 70 else 'Watch' if score >= 55 else 'Ignore'),
            'score_source': fusion['source'], 'live_used': fusion['live_used'], 'live_stale': fusion['live_stale'], 'live_age_seconds': fusion['live_age_seconds'],
            'price': float(d['live_price']) if d['live_price'] is not None else None,
            'change_pct': float(d['live_change_pct'] or 0),
            'volume_multiple': float(d['live_volume'] or 1),
            'risk': _classify_scanner_risk(d),
            'why': [x for x in [
                'Positive public catalyst' if float(d['catalyst_score'] or 0) >= 75 else None,
                'Positive earnings signal' if float(d['earnings_score'] or 0) >= 75 else None,
                f"Price momentum {float(d['live_change_pct']):+.2f}%" if d['live_change_pct'] is not None else None,
                f"Volume {float(d['live_volume']):.1f}x average" if d['live_volume'] is not None and float(d['live_volume']) >= 1.8 else None,
            ] if x],
        })
        out.append(d)
    return out
