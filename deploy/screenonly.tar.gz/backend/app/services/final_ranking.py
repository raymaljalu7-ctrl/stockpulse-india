"""Final quality-first ranking layer for StockPulse India."""
from __future__ import annotations
from typing import Any


def _clamp(value: float, low: float = 0.0, high: float = 100.0) -> float:
    return max(low, min(high, float(value)))


def rank_opportunity(result: dict[str, Any]) -> dict[str, Any]:
    """Create a transparent final ranking without allowing momentum to dominate quality."""
    fundamental = _clamp(result.get('fundamental_analysis', {}).get('score', result.get('fundamental_score', 50)))
    earnings = _clamp(result.get('earnings_score', result.get('earnings_analysis', {}).get('expected_pat_growth', 0) * 1.5 + 50))
    catalyst = _clamp(result.get('catalyst_score', 50))
    technical = _clamp(result.get('technical_score', 50))
    surprise = _clamp(result.get('surprise_score', result.get('earnings_analysis', {}).get('surprise_probability', 50)))
    confidence = _clamp(result.get('confidence', result.get('earnings_analysis', {}).get('confidence', 35)))
    valuation_adjustment = float(result.get('fundamental_analysis', {}).get('valuation_adjustment', 0) or 0)
    revenue_growth = _clamp(result.get('revenue_growth_5y_pct', result.get('fundamental_analysis', {}).get('revenue_growth_5y_pct', 0)) * 2 + 50)
    profit_growth = _clamp(result.get('profit_growth_5y_pct', result.get('fundamental_analysis', {}).get('profit_growth_5y_pct', 0)) * 2 + 50)
    growth_quality = revenue_growth * 0.45 + profit_growth * 0.55

    # Quality remains dominant. Growth and earnings rank strong businesses;
    # valuation prevents an otherwise good company from winning purely on momentum.
    growth_timing = earnings * 0.40 + surprise * 0.15 + catalyst * 0.20 + growth_quality * 0.25
    confirmation = technical * 0.70 + _clamp(result.get('momentum_score', 50)) * 0.30
    raw = fundamental * 0.50 + growth_timing * 0.25 + confirmation * 0.10 + confidence * 0.15
    final_score = _clamp(raw + valuation_adjustment)

    verdict = 'avoid'
    if fundamental >= 80 and confidence >= 60 and final_score >= 75:
        verdict = 'top_quality_opportunity'
    elif fundamental >= 65 and confidence >= 50 and final_score >= 65:
        verdict = 'quality_opportunity'
    elif fundamental >= 50 and final_score >= 55:
        verdict = 'selective_watch'

    if final_score >= 80 and fundamental >= 75:
        grade = 'A'
    elif final_score >= 70 and fundamental >= 65:
        grade = 'B'
    elif final_score >= 55 and fundamental >= 50:
        grade = 'C'
    else:
        grade = 'D'

    reasons: list[str] = []
    if fundamental >= 75:
        reasons.append('Strong fundamental quality is the main ranking driver')
    elif fundamental < 50:
        reasons.append('Fundamental quality is below the preferred level')
    if growth_quality >= 70:
        reasons.append('Long-term revenue/profit growth supports the quality thesis')
    if growth_timing >= 70:
        reasons.append('Earnings/catalyst signals support the opportunity')
    if confirmation >= 70:
        reasons.append('Technical confirmation supports the setup')
    if valuation_adjustment < 0:
        reasons.append('Valuation reduces the final rank')
    if confidence < 50:
        reasons.append('Data/model confidence is limited')

    return {
        'final_rank_score': round(final_score, 2),
        'decision_grade': grade,
        'opportunity_verdict': verdict,
        'ranking_breakdown': {
            'fundamental_quality': round(fundamental, 2),
            'growth_timing': round(growth_timing, 2),
            'growth_quality': round(growth_quality, 2),
            'technical_confirmation': round(confirmation, 2),
            'data_confidence': round(confidence, 2),
            'valuation_adjustment': round(valuation_adjustment, 2),
        },
        'ranking_reasons': reasons[:6],
    }
