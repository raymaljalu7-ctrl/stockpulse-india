from __future__ import annotations
from typing import Any
from app.services.db_opportunity_scanner import scan
from app.services.final_ranking import rank_opportunity


def screen(limit: int = 25, min_quality: float = 60.0, horizon: str | None = None) -> dict[str, Any]:
    """Quality-first stock screen for the personal India scanner.

    The screener deliberately prefers business quality over raw price momentum.
    It only returns persisted/database-backed evidence; it never fabricates a live quote.
    """
    rows = scan(limit=max(50, min(limit * 4, 200)), min_score=0, horizon=horizon)
    ranked: list[dict[str, Any]] = []
    for row in rows:
        fundamental = float(row.get("fundamental_score") or 0)
        if fundamental < min_quality:
            continue
        ranked_row = {**row, **rank_opportunity(row)}
        if ranked_row["final_rank_score"] < min_quality:
            continue
        ranked.append(ranked_row)
    ranked.sort(key=lambda x: (x["final_rank_score"], float(x.get("fundamental_score") or 0)), reverse=True)
    return {
        "status": "database-backed" if rows or ranked else "no_database_evidence",
        "market": "IN",
        "exchange_scope": ["NSE", "BSE"],
        "objective": "quality_first_stock_screen",
        "count": min(len(ranked), limit),
        "items": ranked[:limit],
        "guardrails": {
            "minimum_fundamental_score": min_quality,
            "no_fabricated_live_quotes": True,
            "intraday_radar_is_separate": True,
        },
    }
