from __future__ import annotations
import os
from datetime import datetime, timezone
from typing import Any


def _age_seconds(value: Any) -> float | None:
    if value is None:
        return None
    try:
        dt = value if isinstance(value, datetime) else datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return max(0.0, (datetime.now(timezone.utc) - dt).total_seconds())
    except Exception:
        return None


def fuse(base_score: float, live_score: float | None, live_created_at: Any = None) -> dict[str, Any]:
    """Fuse durable and live scores while protecting the scanner from stale ticks."""
    stale_after = max(1, int(os.getenv('LIVE_SIGNAL_STALE_SECONDS', '120')))
    age = _age_seconds(live_created_at)
    stale = live_score is None or (age is not None and age > stale_after)
    if stale:
        return {'score': round(float(base_score), 2), 'source': 'durable', 'live_used': False,
                'live_stale': live_score is not None, 'live_age_seconds': age}
    score = float(base_score) * 0.35 + float(live_score) * 0.65
    return {'score': round(max(0.0, min(100.0, score)), 2), 'source': 'fused',
            'live_used': True, 'live_stale': False, 'live_age_seconds': age}
