from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.screener import router
app=FastAPI(title="StockPulse India API",version="3.2.0")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
app.include_router(router,prefix="/api")
@app.get("/health")
def health(): return {"status":"ok","service":"stockpulse-api","version":"3.2.0"}
